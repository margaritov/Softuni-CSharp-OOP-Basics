﻿using System;
using System.Linq;

namespace DefiningClasses
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Family family = new Family();
            int n = int.Parse(Console.ReadLine());
            while (n-- > 0)
            {
                string[] data = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);
                family.AddMember(new Person(data[0], int.Parse(data[1])));
            }
           family.GetOlderThan(30).OrderBy(m=>m.Name).ToList().ForEach(m => Console.WriteLine($"{m.Name} - {m.Age}"));
            ;
        }
    }
}
