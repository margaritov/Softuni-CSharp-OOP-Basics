﻿using System;
using System.Linq;

namespace DefiningClasses
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            string s1 = Console.ReadLine();
            string s2 = Console.ReadLine();
            int diff = DateModifier.CalculateDifference(s1, s2);
            Console.WriteLine(diff);
            
        }
    }
}
